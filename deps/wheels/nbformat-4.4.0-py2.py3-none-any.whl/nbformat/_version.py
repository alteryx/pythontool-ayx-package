# Make sure to update package.json, too!
# version_info = (4, 5, 0, 'dev')
version_info = (4, 4, 0)
__version__ = '.'.join(map(str, version_info))
