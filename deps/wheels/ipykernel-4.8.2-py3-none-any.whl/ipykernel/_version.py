version_info = (4, 8, 2)
__version__ = '.'.join(map(str, version_info))

kernel_protocol_version_info = (5, 1)
kernel_protocol_version = '%s.%s' % kernel_protocol_version_info
